


public class servicesprofessional{
    public int sid { get; set; }
    public string  servicecategory {get;set;}
    public string  servicesubcategory {get;set;}
    public string status {get;set;}
}